#include "norykcal.h"
#include "ui_norykcal.h"
#include <QPixmap>
#include <QLabel>

norykcal::norykcal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::norykcal)
{
    ui->setupUi(this);
    QPixmap pix("/home/daman/Downloads/Toronto.png");
    ui->labelpic->setPixmap(pix.scaled(3500,3800,Qt::KeepAspectRatio));
    ;
}

norykcal::~norykcal()
{
    delete ui;
}
