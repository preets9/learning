/********************************************************************************
** Form generated from reading UI file 'holidays.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOLIDAYS_H
#define UI_HOLIDAYS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_HoliDays
{
public:
    QLabel *label;
    QFrame *line;
    QPushButton *pushButton;
    QTextBrowser *textBrowser;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QLabel *label_2;
    QLabel *label_3;

    void setupUi(QDialog *HoliDays)
    {
        if (HoliDays->objectName().isEmpty())
            HoliDays->setObjectName(QString::fromUtf8("HoliDays"));
        HoliDays->resize(1200, 1024);
        label = new QLabel(HoliDays);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 600, 1024));
        line = new QFrame(HoliDays);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(600, 0, 3, 1024));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);
        pushButton = new QPushButton(HoliDays);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(660, 800, 221, 51));
        textBrowser = new QTextBrowser(HoliDays);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(630, 90, 541, 671));
        pushButton_2 = new QPushButton(HoliDays);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(920, 800, 221, 51));
        pushButton_3 = new QPushButton(HoliDays);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(660, 870, 221, 51));
        pushButton_4 = new QPushButton(HoliDays);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(920, 870, 221, 51));
        pushButton_5 = new QPushButton(HoliDays);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(1090, 980, 89, 25));
        label_2 = new QLabel(HoliDays);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(780, 770, 241, 17));
        QFont font;
        font.setPointSize(10);
        label_2->setFont(font);
        label_3 = new QLabel(HoliDays);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(700, 20, 371, 61));

        retranslateUi(HoliDays);

        QMetaObject::connectSlotsByName(HoliDays);
    } // setupUi

    void retranslateUi(QDialog *HoliDays)
    {
        HoliDays->setWindowTitle(QCoreApplication::translate("HoliDays", "Dialog", nullptr));
        label->setText(QString());
        pushButton->setText(QCoreApplication::translate("HoliDays", "GARBAGE ITEMS", nullptr));
        pushButton_2->setText(QCoreApplication::translate("HoliDays", "RECYCLE ITEMS", nullptr));
        pushButton_3->setText(QCoreApplication::translate("HoliDays", "DON'T PUT IN RECYCLE", nullptr));
        pushButton_4->setText(QCoreApplication::translate("HoliDays", "DROP-OFF-DEPOT", nullptr));
        pushButton_5->setText(QCoreApplication::translate("HoliDays", "Close", nullptr));
        label_2->setText(QCoreApplication::translate("HoliDays", "Select the options below to read about it", nullptr));
        label_3->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class HoliDays: public Ui_HoliDays {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOLIDAYS_H
