/********************************************************************************
** Form generated from reading UI file 'haltoncal.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HALTONCAL_H
#define UI_HALTONCAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_HaltonCal
{
public:
    QLabel *label;

    void setupUi(QDialog *HaltonCal)
    {
        if (HaltonCal->objectName().isEmpty())
            HaltonCal->setObjectName(QString::fromUtf8("HaltonCal"));
        HaltonCal->resize(2048, 1200);
        label = new QLabel(HaltonCal);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 2048, 1200));

        retranslateUi(HaltonCal);

        QMetaObject::connectSlotsByName(HaltonCal);
    } // setupUi

    void retranslateUi(QDialog *HaltonCal)
    {
        HaltonCal->setWindowTitle(QCoreApplication::translate("HaltonCal", "Dialog", nullptr));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class HaltonCal: public Ui_HaltonCal {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HALTONCAL_H
