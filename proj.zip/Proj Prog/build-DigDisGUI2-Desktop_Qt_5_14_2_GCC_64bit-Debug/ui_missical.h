/********************************************************************************
** Form generated from reading UI file 'missical.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MISSICAL_H
#define UI_MISSICAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Missical
{
public:
    QLabel *label;

    void setupUi(QDialog *Missical)
    {
        if (Missical->objectName().isEmpty())
            Missical->setObjectName(QString::fromUtf8("Missical"));
        Missical->resize(2048, 1200);
        label = new QLabel(Missical);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 2048, 1200));

        retranslateUi(Missical);

        QMetaObject::connectSlotsByName(Missical);
    } // setupUi

    void retranslateUi(QDialog *Missical)
    {
        Missical->setWindowTitle(QCoreApplication::translate("Missical", "Dialog", nullptr));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Missical: public Ui_Missical {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MISSICAL_H
