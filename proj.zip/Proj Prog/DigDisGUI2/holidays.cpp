#include "holidays.h"
#include "ui_holidays.h"

HoliDays::HoliDays(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::HoliDays)
{
    ui->setupUi(this);
    QPixmap pix("/home/daman/Downloads/Holiday.png");
    ui->label->setPixmap(pix.scaled(800,800,Qt::KeepAspectRatio));
}

HoliDays::~HoliDays()
{
    delete ui;
}
