#include "kichncal.h"
#include "ui_kichncal.h"

KichnCal::KichnCal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::KichnCal)
{
    ui->setUp
}

KichnCal::~KichnCal()
{
    delete ui;
}
