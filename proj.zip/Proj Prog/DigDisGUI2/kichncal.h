#ifndef KICHNCAL_H
#define KICHNCAL_H

#include <QDialog>

namespace Ui {
class KichnCal;
}

class KichnCal : public QDialog
{
    Q_OBJECT

public:
    explicit KichnCal(QWidget *parent = nullptr);
    ~KichnCal();

private:
    Ui::KichnCal *ui;
};

#endif // KICHNCAL_H
